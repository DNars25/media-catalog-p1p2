export default function SeriesPage() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Séries</h1></div>
}
```