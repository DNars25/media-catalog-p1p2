export default function FilmesPage() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Filmes</h1></div>
}
```